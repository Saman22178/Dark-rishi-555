/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      animation: {
        'rgb-glow': 'rgb 8s linear infinite',
      },
      keyframes: {
        rgb: {
          '0%': { 'text-shadow': '0 0 10px red' },
          '33%': { 'text-shadow': '0 0 10px blue' },
          '66%': { 'text-shadow': '0 0 10px green' },
          '100%': { 'text-shadow': '0 0 10px red' },
        }
      }
    },
  },
  plugins: [],
  }

