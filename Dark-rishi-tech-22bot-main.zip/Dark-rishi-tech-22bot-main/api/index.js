import { makeWASocket, useMultiFileAuthState } from '@whiskeysockets/baileys';
import pino from 'pino';

export default async function handler(req, res) {
    if (req.method !== 'POST') return res.status(405).json({ error: "Method not allowed" });

    const { phone } = req.body;
    if (!phone) return res.status(400).json({ error: "අංකය ඇතුළත් කරන්න" });

    try {
        const { state } = await useMultiFileAuthState('/tmp/session');
        
        const sock = makeWASocket({
            auth: state,
            printQRInTerminal: false,
            logger: pino({ level: 'silent' }),
            browser: ["Mac OS", "Chrome", "10.15.7"]
        });

        // සර්වර් එකට සම්බන්ධ වීමට උපරිම තත්පර 8ක් උත්සාහ කරයි
        const code = await sock.makeRegistrationCode(phone.trim());
        
        if (code) {
            return res.status(200).json({ code });
        } else {
            return res.status(500).json({ error: "කේතය ලබාගත නොහැකි විය" });
        }

    } catch (err) {
        console.error(err);
        return res.status(500).json({ error: "සර්වර් එක අවිවේකීයි, පසුව උත්සාහ කරන්න" });
    }
}
