import React, { useState } from 'react';

function App() {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [pairingCode, setPairingCode] = useState('');
  const [loading, setLoading] = useState(false);

  const getPairingCode = async () => {
    if (!phoneNumber) return alert("අංකය ඇතුළත් කරන්න!");
    setLoading(true);
    try {
      const response = await fetch('/api/pair', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone: phoneNumber }),
      });
      const data = await response.json();
      if (data.code) {
        setPairingCode(data.code);
      } else {
        alert("දෝෂයකි: " + (data.error || "Backend Error"));
      }
    } catch (e) {
      alert("සම්බන්ධතාව බිඳ වැටුණි!");
    }
    setLoading(false);
  };

  return (
    <div style={{ backgroundColor: '#050505', minHeight: '100vh', color: 'white', padding: '20px', fontFamily: 'sans-serif' }}>
      
      {/* RGB Title Section */}
      <center style={{ padding: '40px 0' }}>
        <h1 style={{ 
          fontSize: '32px', 
          fontWeight: '900', 
          letterSpacing: '-1px',
          background: 'linear-gradient(to right, #ff0000, #00ff00, #0000ff, #ff0000)',
          WebkitBackgroundClip: 'text',
          WebkitTextFillColor: 'transparent',
          animation: 'rgb 5s linear infinite',
          textTransform: 'uppercase',
          backgroundSize: '200% auto'
        }}>
          DARK RISHI PANNEL
        </h1>
        <style>{`
          @keyframes rgb {
            to { background-position: 200% center; }
          }
        `}</style>
      </center>

      {/* Main Card */}
      <div style={{ 
        maxWidth: '400px', 
        margin: 'auto', 
        background: 'rgba(255,255,255,0.05)', 
        backdropFilter: 'blur(10px)', 
        border: '1px solid rgba(255,255,255,0.1)', 
        borderRadius: '25px', 
        padding: '25px',
        boxShadow: '0 10px 30px rgba(0,0,0,0.5)'
      }}>
        
        <h2 style={{ color: '#06b6d4', fontSize: '18px', fontWeight: 'bold', marginBottom: '5px' }}>Pairing Interface</h2>
        <p style={{ color: '#666', fontSize: '12px', marginBottom: '20px' }}>thishuwa-MD • Connect WhatsApp</p>

        <label style={{ fontSize: '10px', color: '#06b6d4', fontWeight: 'bold', display: 'block', marginBottom: '8px', letterSpacing: '1px' }}>PHONE NUMBER</label>
        <input 
          type="text" 
          placeholder="947xxxxxxxx" 
          value={phoneNumber}
          onChange={(e) => setPhoneNumber(e.target.value)}
          style={{ width: '100%', padding: '15px', borderRadius: '15px', border: '1px solid #333', background: '#000', color: '#fff', marginBottom: '20px', outline: 'none', boxSizing: 'border-box' }}
        />

        <button 
          onClick={getPairingCode}
          disabled={loading}
          style={{ 
            width: '100%', 
            padding: '15px', 
            borderRadius: '15px', 
            border: 'none', 
            background: loading ? '#333' : '#0891b2', 
            color: '#fff', 
            fontWeight: 'bold', 
            cursor: loading ? 'not-allowed' : 'pointer',
            boxShadow: loading ? 'none' : '0 0 15px rgba(8,145,178,0.4)',
            transition: '0.3s'
          }}
        >
          {loading ? "Generating..." : "Get Pairing Code"}
        </button>

        {pairingCode && (
          <div style={{ marginTop: '25px', padding: '20px', background: 'rgba(0,255,0,0.05)', border: '1px solid rgba(0,255,0,0.2)', borderRadius: '20px', textAlign: 'center' }}>
            <p style={{ fontSize: '10px', color: '#4ade80', marginBottom: '10px' }}>YOUR PAIRING CODE</p>
            <h3 style={{ fontSize: '35px', fontWeight: 'bold', letterSpacing: '5px' }}>{pairingCode}</h3>
            <button 
              onClick={() => {navigator.clipboard.writeText(pairingCode); alert("Copied!");}} 
              style={{ background: 'none', border: '1px solid #444', color: '#aaa', padding: '5px 15px', borderRadius: '10px', marginTop: '10px', fontSize: '12px', cursor: 'pointer' }}
            >
              Copy Code
            </button>
          </div>
        )}
      </div>

      <center style={{ marginTop: '50px', opacity: '0.5', fontSize: '12px', letterSpacing: '2px' }}>
        THISHU MD V-1
      </center>

    </div>
  );
}

export default App;
        
